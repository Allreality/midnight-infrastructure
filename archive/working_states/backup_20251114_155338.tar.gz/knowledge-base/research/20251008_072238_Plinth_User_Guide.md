---
{
  "agent": "Research Curator",
  "researched_by": "Fallback",
  "timestamp": "2025-10-08T07:22:38.030840",
  "created": "2025-10-08T07:22:38.030899",
  "category": "research",
  "title": "Plinth User Guide"
}
---

# Plinth User Guide

Research on Plinth User Guide (API Error: Error code: 401 - {'type': 'error', 'error': {'type': 'authentication_error', 'message': 'invalid x-api-key'}, 'request_id': 'req_011CTueMWYoBoWZbGMLonaiB'})