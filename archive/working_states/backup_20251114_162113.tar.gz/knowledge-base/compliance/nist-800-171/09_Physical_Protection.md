---
control_family: "Physical Protection"
nist_id: "3.10"
---
# Physical Protection
**3.10.1-3.10.6:** Facility security, physical access controls, visitor management
**Midnight Integration:** Hardware tamper detection (SEV-SNP), blockchain-logged physical access
**Advantage:** Even with physical access, hardware encryption protects data
**Status:** Complete ✅
