---
{
  "agent": "Research Curator",
  "researched_by": "Fallback",
  "timestamp": "2025-10-09T06:42:07.475179",
  "created": "2025-10-09T06:42:07.475294",
  "category": "research",
  "title": "Midnight Indexer API Documentation v1"
}
---

# Midnight Indexer API Documentation v1

Research on Midnight Indexer API Documentation v1 (API Error: Error code: 401 - {'type': 'error', 'error': {'type': 'authentication_error', 'message': 'invalid x-api-key'}, 'request_id': 'req_011CTwV5FjL5VcSzsr16hFGg'})