# Midnight Infrastructure Knowledge Base

## 📚 Organization

- `/blockchain` - Blockchain compliance and regulations
- `/airdrop` - Airdrop mechanics, eligibility, claims
- `/compliance` - Legal and regulatory frameworks
- `/research` - Latest research and analysis
- `/agents` - Agent behaviors and instructions

## 📊 Statistics

Last Updated: $(date)
Total Documents: TBD
Categories: 5
