# 🚀 Service Monitor Dashboard - Quick Start

## What You're Getting

A beautiful Project Dashboard (port 5000) that shows:
- ✅ All running services with green indicators
- ❌ Stopped services with red indicators  
- 🔢 Port numbers for each service
- 🔗 Clickable links to open running services
- 📊 Statistics (Running/Stopped/Total)
- 🔄 Auto-refresh every 10 seconds
- 💫 Modern, responsive design

---

## Option 1: Quick Replace (EASIEST)

Replace your entire server.py with the new version:

```bash
# 1. Backup your current server.py
cd /mnt/c/projects/project-dashboard
cp server.py server.py.backup

# 2. Copy the new dashboard
cp /mnt/user-data/outputs/dashboard_with_monitor.py server.py

# 3. Install dependencies (if not already done)
source venv/bin/activate
pip install fastapi uvicorn

# 4. Start the dashboard
python3 server.py
```

**Done!** Open http://localhost:5000 in your browser.

---

## Option 2: Add to Existing Dashboard

If you want to keep your existing dashboard and just add the monitor:

### Step 1: Copy the service_monitor.py module

```bash
cp /mnt/user-data/outputs/service_monitor.py /mnt/c/projects/project-dashboard/
```

### Step 2: Add imports to your server.py

```python
from service_monitor import ServiceMonitor
from fastapi.responses import JSONResponse
```

### Step 3: Add API endpoint

```python
@app.get("/api/services")
async def get_services():
    monitor = ServiceMonitor()
    services = monitor.get_all_services_status()
    return JSONResponse(content=services)
```

### Step 4: Add HTML/CSS/JS

See the complete code in `INTEGRATION_GUIDE.md`

---

## What It Looks Like

```
┌──────────────────────────────────────────────────────┐
│  📊 Project Dashboard                                │
│  Time tracking & project management                  │
└──────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────┐
│  🚀 Service Status Monitor             [🔄 Refresh]  │
├──────────────────────────────────────────────────────┤
│                                                        │
│  ┌──────────────┐  ┌──────────────┐  ┌─────────────┐│
│  │🟢 Project    │  │🟢 Service    │  │🟢 Midnight  ││
│  │  Dashboard   │  │  Manager     │  │  Infra...   ││
│  │    :5000     │  │    :5005     │  │    :5003    ││
│  │              │  │              │  │             ││
│  │ PID: 12345   │  │ PID: 12346   │  │ PID: 12347  ││
│  │ [Open →]     │  │ [Open →]     │  │ [Open →]    ││
│  └──────────────┘  └──────────────┘  └─────────────┘│
│                                                        │
│  ┌──────────────┐  ┌──────────────┐  ┌─────────────┐│
│  │🔴 Project    │  │🔴 Trading    │  │🔴 Trading   ││
│  │  Hub         │  │  Control     │  │  Bot        ││
│  │    :5001     │  │    :5002     │  │    :5004    ││
│  │  (Stopped)   │  │  (Stopped)   │  │  (Stopped)  ││
│  └──────────────┘  └──────────────┘  └─────────────┘│
│                                                        │
│  ┌──────────────────────────────────────────────────┐│
│  │  Running: 3    Stopped: 3    Total Services: 6  ││
│  └──────────────────────────────────────────────────┘│
└──────────────────────────────────────────────────────┘
```

---

## Features

### Real-Time Monitoring
- Auto-refreshes every 10 seconds
- Shows current status instantly
- Click "Refresh" button anytime

### Service Cards Show:
- **Green dot (🟢)** = Service is running
- **Red dot (🔴)** = Service is stopped
- **Port number** = Where to access it
- **PID** = Process ID (for running services)
- **Open link** = Click to open the service

### Services Monitored:
- Port 5000: Project Dashboard
- Port 5001: Project Hub
- Port 5002: Trading Control Panel
- Port 5003: Midnight Infrastructure
- Port 5004: Trading Bot Dashboard
- Port 5005: Service Manager

---

## Customization

Want to add/change services? Edit the `KNOWN_SERVICES` dictionary:

```python
KNOWN_SERVICES = {
    5000: {'name': 'Your Service Name', 'description': 'What it does'},
    5001: {'name': 'Another Service', 'description': 'Description here'},
    # Add more...
}
```

---

## Troubleshooting

### "lsof: command not found"
Install lsof:
```bash
sudo apt-get install lsof  # Ubuntu/Debian
```

### Services not showing as running
Make sure they're actually started:
```bash
lsof -i :5000  # Check specific port
ps aux | grep python  # Check Python processes
```

### Port already in use
Kill the process:
```bash
lsof -i :5000
kill <PID>
```

---

## Testing

1. **Start the dashboard:**
   ```bash
   cd /mnt/c/projects/project-dashboard
   source venv/bin/activate
   python3 server.py
   ```

2. **Open browser:** http://localhost:5000

3. **You should see:**
   - Service monitor panel at top
   - At least Project Dashboard shown as running (🟢)
   - Other services shown as stopped (🔴) or running

4. **Test refresh:**
   - Start another service (like Midnight Infrastructure)
   - Click "Refresh" button
   - New service should appear as running

---

## Files Included

1. **dashboard_with_monitor.py** - Complete ready-to-use dashboard
2. **service_monitor.py** - Standalone module for monitoring
3. **INTEGRATION_GUIDE.md** - Detailed integration instructions
4. **This file** - Quick start guide

---

## What's Next?

Once your dashboard is working:

1. ✅ Start other services and watch them appear
2. ✅ Use the links to quickly access each service
3. ✅ Monitor which services are running at a glance
4. ✅ Customize the service list as needed

---

## Support

- Check `INTEGRATION_GUIDE.md` for detailed instructions
- See `SERVICE_MANAGER_FIXES_2025-10-28.md` for troubleshooting
- Use `QUICK_REFERENCE.md` for common commands

---

**Status:** Ready to use  
**Time to setup:** 2-5 minutes  
**Dependencies:** fastapi, uvicorn (already in your requirements)
