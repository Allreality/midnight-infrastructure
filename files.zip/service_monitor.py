"""
Service Monitor - Detect running services and their ports
Add this to your Project Dashboard to show what's running
"""

import subprocess
import re
from typing import List, Dict, Optional

class ServiceMonitor:
    """Monitor running services and their ports"""
    
    # Define your services and their expected ports
    KNOWN_SERVICES = {
        5000: {'name': 'Project Dashboard', 'description': 'Time tracking & project management'},
        5001: {'name': 'Project Hub', 'description': 'Central dashboard for all projects'},
        5002: {'name': 'Trading Control Panel', 'description': 'Trading bot control interface'},
        5003: {'name': 'Midnight Infrastructure', 'description': 'Blockchain development platform'},
        5004: {'name': 'Trading Bot Dashboard', 'description': 'Solana AI-powered trading bot'},
        5005: {'name': 'Service Manager', 'description': 'Multi-service control center'},
        8080: {'name': 'Trading Bot (Alt)', 'description': 'Trading bot alternative port'},
    }
    
    @staticmethod
    def get_running_services() -> List[Dict]:
        """
        Get list of running services on known ports
        Returns: List of dicts with service info
        """
        running_services = []
        
        try:
            # Run lsof to find processes listening on ports
            result = subprocess.run(
                ['lsof', '-i', '-P', '-n'],
                capture_output=True,
                text=True,
                timeout=5
            )
            
            # Parse the output
            lines = result.stdout.split('\n')
            
            for line in lines[1:]:  # Skip header
                if 'LISTEN' in line:
                    # Extract port number
                    match = re.search(r':(\d+)\s+\(LISTEN\)', line)
                    if match:
                        port = int(match.group(1))
                        
                        # Check if it's one of our known services
                        if port in ServiceMonitor.KNOWN_SERVICES:
                            # Extract process info
                            parts = line.split()
                            if len(parts) >= 2:
                                command = parts[0]
                                pid = parts[1]
                                
                                service_info = ServiceMonitor.KNOWN_SERVICES[port].copy()
                                service_info.update({
                                    'port': port,
                                    'status': 'running',
                                    'pid': pid,
                                    'command': command,
                                    'url': f'http://localhost:{port}'
                                })
                                running_services.append(service_info)
        
        except Exception as e:
            print(f"Error getting services: {e}")
        
        return running_services
    
    @staticmethod
    def get_all_services_status() -> List[Dict]:
        """
        Get status of all known services (running or stopped)
        Returns: List of all services with their status
        """
        running = ServiceMonitor.get_running_services()
        running_ports = {s['port'] for s in running}
        
        all_services = []
        
        # Add running services
        all_services.extend(running)
        
        # Add stopped services
        for port, info in ServiceMonitor.KNOWN_SERVICES.items():
            if port not in running_ports:
                service_info = info.copy()
                service_info.update({
                    'port': port,
                    'status': 'stopped',
                    'pid': None,
                    'command': None,
                    'url': f'http://localhost:{port}'
                })
                all_services.append(service_info)
        
        # Sort by port number
        all_services.sort(key=lambda x: x['port'])
        
        return all_services
    
    @staticmethod
    def get_service_by_port(port: int) -> Optional[Dict]:
        """Get status of a specific service by port"""
        services = ServiceMonitor.get_all_services_status()
        for service in services:
            if service['port'] == port:
                return service
        return None
    
    @staticmethod
    def format_for_html() -> str:
        """Generate HTML for displaying services"""
        services = ServiceMonitor.get_all_services_status()
        
        html = """
        <div class="service-status-panel">
            <h3>🚀 Service Status Monitor</h3>
            <div class="services-grid">
        """
        
        for service in services:
            status_class = 'running' if service['status'] == 'running' else 'stopped'
            status_icon = '🟢' if service['status'] == 'running' else '🔴'
            
            html += f"""
            <div class="service-card {status_class}">
                <div class="service-header">
                    <span class="status-icon">{status_icon}</span>
                    <span class="service-name">{service['name']}</span>
                    <span class="service-port">:{service['port']}</span>
                </div>
                <div class="service-description">{service['description']}</div>
            """
            
            if service['status'] == 'running':
                html += f"""
                <div class="service-details">
                    <small>PID: {service['pid']} | <a href="{service['url']}" target="_blank">Open</a></small>
                </div>
                """
            
            html += "</div>"
        
        html += """
            </div>
        </div>
        """
        
        return html


# Example usage for FastAPI
def get_services_endpoint():
    """FastAPI endpoint to return services as JSON"""
    from fastapi import FastAPI
    from fastapi.responses import JSONResponse
    
    monitor = ServiceMonitor()
    services = monitor.get_all_services_status()
    return JSONResponse(content=services)


# Example usage for Flask
def get_services_flask():
    """Flask endpoint to return services as JSON"""
    from flask import jsonify
    
    monitor = ServiceMonitor()
    services = monitor.get_all_services_status()
    return jsonify(services)


if __name__ == "__main__":
    # Test the monitor
    print("=== Service Status Monitor ===\n")
    
    monitor = ServiceMonitor()
    services = monitor.get_all_services_status()
    
    print(f"Found {len(services)} services:\n")
    
    for service in services:
        status = "✅ RUNNING" if service['status'] == 'running' else "❌ STOPPED"
        print(f"{status} | Port {service['port']:4d} | {service['name']}")
        print(f"         {service['description']}")
        if service['status'] == 'running':
            print(f"         PID: {service['pid']} | URL: {service['url']}")
        print()
