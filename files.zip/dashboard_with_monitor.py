"""
Complete Project Dashboard with Service Monitor
Ready to use - just copy to your project-dashboard directory
"""

from fastapi import FastAPI
from fastapi.responses import HTMLResponse, JSONResponse
import subprocess
import re
from typing import List, Dict

app = FastAPI()

# Service definitions
KNOWN_SERVICES = {
    5000: {'name': 'Project Dashboard', 'description': 'Time tracking & project management'},
    5001: {'name': 'Project Hub', 'description': 'Central dashboard for all projects'},
    5002: {'name': 'Trading Control Panel', 'description': 'Trading bot control interface'},
    5003: {'name': 'Midnight Infrastructure', 'description': 'Blockchain development platform'},
    5004: {'name': 'Trading Bot Dashboard', 'description': 'Solana AI-powered trading bot'},
    5005: {'name': 'Service Manager', 'description': 'Multi-service control center'},
}

def get_running_services() -> List[Dict]:
    """Get list of running services"""
    running_services = []
    
    try:
        result = subprocess.run(
            ['lsof', '-i', '-P', '-n'],
            capture_output=True,
            text=True,
            timeout=5
        )
        
        lines = result.stdout.split('\n')
        
        for line in lines[1:]:
            if 'LISTEN' in line:
                match = re.search(r':(\d+)\s+\(LISTEN\)', line)
                if match:
                    port = int(match.group(1))
                    
                    if port in KNOWN_SERVICES:
                        parts = line.split()
                        if len(parts) >= 2:
                            service_info = KNOWN_SERVICES[port].copy()
                            service_info.update({
                                'port': port,
                                'status': 'running',
                                'pid': parts[1],
                                'command': parts[0],
                                'url': f'http://localhost:{port}'
                            })
                            running_services.append(service_info)
    
    except Exception as e:
        print(f"Error: {e}")
    
    return running_services

def get_all_services_status() -> List[Dict]:
    """Get status of all services"""
    running = get_running_services()
    running_ports = {s['port'] for s in running}
    
    all_services = []
    all_services.extend(running)
    
    for port, info in KNOWN_SERVICES.items():
        if port not in running_ports:
            service_info = info.copy()
            service_info.update({
                'port': port,
                'status': 'stopped',
                'pid': None,
                'url': f'http://localhost:{port}'
            })
            all_services.append(service_info)
    
    all_services.sort(key=lambda x: x['port'])
    return all_services

@app.get("/api/services")
async def api_get_services():
    """API endpoint for service status"""
    services = get_all_services_status()
    return JSONResponse(content=services)

@app.get("/", response_class=HTMLResponse)
async def dashboard():
    """Main dashboard"""
    return """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Project Dashboard - Service Monitor</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
        }

        .main-header {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 30px 40px;
            margin-bottom: 30px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
        }

        .main-header h1 {
            color: #667eea;
            font-size: 2.5em;
            margin-bottom: 10px;
        }

        .main-header p {
            color: #666;
            font-size: 1.1em;
        }

        .service-status-container {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
        }

        .panel-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
        }

        .panel-header h2 {
            margin: 0;
            font-size: 1.8em;
            color: #1f2937;
        }

        .refresh-btn {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
            color: white;
            padding: 12px 24px;
            border-radius: 10px;
            cursor: pointer;
            font-size: 1em;
            font-weight: 600;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
        }

        .refresh-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(102, 126, 234, 0.6);
        }

        .services-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
            gap: 20px;
        }

        .service-card {
            background: white;
            border-radius: 15px;
            padding: 20px;
            transition: all 0.3s ease;
            border-left: 5px solid #ccc;
            position: relative;
            overflow: hidden;
        }

        .service-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 3px;
            background: linear-gradient(90deg, transparent, rgba(102, 126, 234, 0.3), transparent);
            opacity: 0;
            transition: opacity 0.3s ease;
        }

        .service-card:hover::before {
            opacity: 1;
        }

        .service-card.running {
            border-left-color: #10b981;
            box-shadow: 0 4px 6px rgba(16, 185, 129, 0.1);
        }

        .service-card.stopped {
            border-left-color: #ef4444;
            opacity: 0.6;
        }

        .service-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 12px 24px rgba(0, 0, 0, 0.15);
        }

        .service-header {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 12px;
        }

        .status-icon {
            font-size: 1.5em;
            animation: pulse 2s ease-in-out infinite;
        }

        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.7; }
        }

        .service-card.stopped .status-icon {
            animation: none;
        }

        .service-name {
            flex: 1;
            color: #1f2937;
            font-weight: 700;
            font-size: 1.1em;
        }

        .service-port {
            background: #f3f4f6;
            padding: 6px 12px;
            border-radius: 8px;
            font-family: 'Courier New', monospace;
            color: #6b7280;
            font-size: 0.95em;
            font-weight: 600;
        }

        .service-description {
            color: #6b7280;
            font-size: 0.95em;
            margin-bottom: 12px;
            line-height: 1.5;
            min-height: 45px;
        }

        .service-details {
            margin-top: 12px;
            padding-top: 12px;
            border-top: 1px solid #e5e7eb;
            font-size: 0.9em;
            color: #9ca3af;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .service-details a {
            color: #667eea;
            text-decoration: none;
            font-weight: 600;
            padding: 6px 12px;
            border-radius: 6px;
            background: rgba(102, 126, 234, 0.1);
            transition: all 0.2s ease;
        }

        .service-details a:hover {
            background: rgba(102, 126, 234, 0.2);
            transform: scale(1.05);
        }

        .loading {
            text-align: center;
            padding: 40px;
            color: #6b7280;
            font-size: 1.2em;
        }

        .spinner {
            border: 3px solid #f3f4f6;
            border-top: 3px solid #667eea;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            animation: spin 1s linear infinite;
            margin: 0 auto 20px;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        .stats {
            display: flex;
            gap: 20px;
            margin-top: 20px;
            padding: 20px;
            background: rgba(102, 126, 234, 0.1);
            border-radius: 12px;
        }

        .stat {
            flex: 1;
            text-align: center;
        }

        .stat-value {
            font-size: 2em;
            font-weight: 700;
            color: #667eea;
        }

        .stat-label {
            color: #6b7280;
            font-size: 0.9em;
            margin-top: 5px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="main-header">
            <h1>📊 Project Dashboard</h1>
            <p>Time tracking & project management with live service monitoring</p>
        </div>

        <div class="service-status-container">
            <div class="panel-header">
                <h2>🚀 Service Status Monitor</h2>
                <button onclick="refreshServices()" class="refresh-btn">🔄 Refresh</button>
            </div>
            
            <div id="services-grid" class="services-grid">
                <div class="loading">
                    <div class="spinner"></div>
                    Loading services...
                </div>
            </div>

            <div class="stats" id="stats" style="display: none;">
                <div class="stat">
                    <div class="stat-value" id="running-count">0</div>
                    <div class="stat-label">Running</div>
                </div>
                <div class="stat">
                    <div class="stat-value" id="stopped-count">0</div>
                    <div class="stat-label">Stopped</div>
                </div>
                <div class="stat">
                    <div class="stat-value" id="total-count">0</div>
                    <div class="stat-label">Total Services</div>
                </div>
            </div>
        </div>
    </div>

    <script>
        async function loadServices() {
            const grid = document.getElementById('services-grid');
            const statsDiv = document.getElementById('stats');
            
            grid.innerHTML = '<div class="loading"><div class="spinner"></div>Loading services...</div>';
            
            try {
                const response = await fetch('/api/services');
                const services = await response.json();
                
                grid.innerHTML = '';
                
                let runningCount = 0;
                let stoppedCount = 0;
                
                services.forEach(service => {
                    const card = document.createElement('div');
                    card.className = `service-card ${service.status}`;
                    
                    if (service.status === 'running') runningCount++;
                    else stoppedCount++;
                    
                    const statusIcon = service.status === 'running' ? '🟢' : '🔴';
                    
                    let detailsHTML = '';
                    if (service.status === 'running') {
                        detailsHTML = `
                            <div class="service-details">
                                <span>PID: ${service.pid}</span>
                                <a href="${service.url}" target="_blank">Open Dashboard →</a>
                            </div>
                        `;
                    }
                    
                    card.innerHTML = `
                        <div class="service-header">
                            <span class="status-icon">${statusIcon}</span>
                            <span class="service-name">${service.name}</span>
                            <span class="service-port">:${service.port}</span>
                        </div>
                        <div class="service-description">${service.description}</div>
                        ${detailsHTML}
                    `;
                    
                    grid.appendChild(card);
                });

                // Update stats
                document.getElementById('running-count').textContent = runningCount;
                document.getElementById('stopped-count').textContent = stoppedCount;
                document.getElementById('total-count').textContent = services.length;
                statsDiv.style.display = 'flex';
                
            } catch (error) {
                grid.innerHTML = '<div class="loading" style="color: #ef4444;">❌ Error loading services</div>';
                console.error('Error:', error);
            }
        }

        function refreshServices() {
            loadServices();
        }

        // Load on page load
        document.addEventListener('DOMContentLoaded', loadServices);

        // Auto-refresh every 10 seconds
        setInterval(loadServices, 10000);
    </script>
</body>
</html>
    """

if __name__ == "__main__":
    import uvicorn
    print("🚀 Starting Project Dashboard on http://localhost:5000")
    print("📊 Service Monitor enabled")
    uvicorn.run(app, host="0.0.0.0", port=5000)
