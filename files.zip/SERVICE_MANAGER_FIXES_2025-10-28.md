# Multi-Service Manager - Troubleshooting & Fixes Documentation
**Date:** October 28, 2025  
**Issue:** Service Manager start buttons not working  
**Status:** ✅ PARTIALLY RESOLVED - Midnight Infrastructure working, others need dependency fixes

---

## 🔍 PROBLEM SUMMARY

The Multi-Service Manager (running on port 5005) displayed a dashboard with start/stop buttons for multiple services, but the buttons were not starting the services correctly.

### Root Causes Identified:

1. **❌ Port Conflicts** - Multiple processes trying to use port 5005
2. **❌ Incorrect Path Mappings** - Services pointed to wrong directories/files
3. **❌ Missing Dependencies** - Virtual environments missing required packages
4. **⚠️ Browser Extension Interference** - dapp-connector extension causing JS errors

---

## 📊 SERVICE INVENTORY

### Current Service Structure:

| Service Name | Port | Path | Script | Status |
|--------------|------|------|--------|--------|
| **Service Manager** | 5005 | `/mnt/c/projects/service_manager` | `api.py` | ✅ Running |
| **Project Dashboard** | 5000 | `/mnt/c/projects/project-dashboard` | `server.py` | ❌ Missing deps |
| **Project Hub** | 5001 | `/mnt/c/projects/project-hub` | `app.py` | ❓ Unknown |
| **Trading Control** | 5002 | `/mnt/c/projects/akil-studio/tx-hub/Trading-bot` | `trading_bot_dashboard.py` | ❓ Unknown |
| **Midnight Infrastructure** | 5003 | `/mnt/c/projects/midnight-infrastructure` | `app.py` | ✅ Working |
| **Trading Bot Dashboard** | 5004 | `/mnt/c/projects/akil-studio/tx-hub/Trading-bot` | `trading_bot_dashboard.py` | ❓ Unknown |

---

## 🔧 FIXES APPLIED

### Fix 1: Killed Conflicting Processes

**Problem:** Two processes were both trying to use port 5005:
```bash
Process 1122158: python3 api.py (started 16:15)
Process 1125028: /mnt/c/projects/project-dashboard/venv/bin/python3 api.py (started 16:26)
```

**Solution:**
```bash
kill 1122158
kill 1125028
lsof -i :5005  # Verify port is free
```

### Fix 2: Corrected Path Mappings in api.py

**Problem:** The `SERVICES` dictionary in `/mnt/c/projects/service_manager/api.py` had incorrect paths.

**Incorrect Mappings:**
```python
'project_dashboard': {
    'script_path': '/mnt/c/projects/project-hub/app.py',  # ❌ WRONG!
}
'midnight': {
    'script_path': '/mnt/c/projects/midnight-infrastructure/server.py',  # ❌ WRONG!
}
'trading_control': {
    'script_path': '/mnt/c/projects/trading-control/app.py',  # ❌ DOESN'T EXIST!
}
```

**Corrected Mappings:**
```python
'project_dashboard': {
    'script_path': '/mnt/c/projects/project-dashboard/server.py',  # ✅ FIXED
}
'midnight': {
    'script_path': '/mnt/c/projects/midnight-infrastructure/app.py',  # ✅ FIXED
}
'trading_control': {
    'script_path': '/mnt/c/projects/akil-studio/tx-hub/Trading-bot/trading_bot_dashboard.py',  # ✅ FIXED
}
```

**Commands Used:**
```bash
cd /mnt/c/projects/service_manager
cp api.py api.py.backup_$(date +%Y%m%d_%H%M%S)

sed -i "s|'script_path': '/mnt/c/projects/project-hub/app.py'|'script_path': '/mnt/c/projects/project-dashboard/server.py'|g" api.py

sed -i "s|'script_path': '/mnt/c/projects/midnight-infrastructure/server.py'|'script_path': '/mnt/c/projects/midnight-infrastructure/app.py'|g" api.py

sed -i "s|'script_path': '/mnt/c/projects/trading-control/app.py'|'script_path': '/mnt/c/projects/akil-studio/tx-hub/Trading-bot/trading_bot_dashboard.py'|g" api.py
```

### Fix 3: Started Service Manager Properly

**Commands:**
```bash
cd /mnt/c/projects/service_manager
source venv/bin/activate
python3 api.py
```

**Result:** Service Manager now running correctly on port 5005 ✅

---

## ❌ REMAINING ISSUES

### Issue 1: Missing Python Dependencies

**Problem:** Project Dashboard cannot start due to missing `fastapi` module.

**Error:**
```
ModuleNotFoundError: No module named 'fastapi'
```

**Solution (IN PROGRESS):**
```bash
cd /mnt/c/projects/project-dashboard
source venv/bin/activate
pip install fastapi uvicorn python-multipart jinja2 requests
python3 server.py
```

**Action Required:** Test each service and install missing dependencies

### Issue 2: Missing requirements.txt Files

**Problem:** No `requirements.txt` files exist for dependency management.

**Action Required:** Create requirements.txt for each service after determining dependencies.

### Issue 3: Browser Extension Interference

**Problem:** dapp-connector browser extension causing JavaScript errors:
```
TypeError: Failed to execute 'observe' on 'MutationObserver': parameter 1 is not of type 'Node'
at chrome-extension://b...ContentScript.js:28
```

**Solution:** Temporarily disable dapp-connector extension for testing.

---

## 📋 NEXT STEPS

### Immediate Actions (Priority Order):

1. **✅ Install Dependencies for Each Service**
   ```bash
   # For each service:
   cd /mnt/c/projects/<service-directory>
   source venv/bin/activate
   pip install <required-packages>
   python3 <service-script>.py
   ```

2. **📝 Create requirements.txt Files**
   ```bash
   # After dependencies are installed:
   pip freeze > requirements.txt
   ```

3. **🧪 Test Each Service Individually**
   - Start each service manually
   - Verify it runs without errors
   - Document any additional dependencies needed

4. **🔄 Test Service Manager Integration**
   - Start Service Manager
   - Use web interface to start/stop each service
   - Verify status updates correctly

5. **📚 Document Final Configuration**
   - Update this document with working configurations
   - Create startup scripts for each service
   - Document environment variables needed

---

## 🐛 DEBUGGING REFERENCE

### Check Running Processes:
```bash
ps aux | grep python
ps aux | grep node
```

### Check Port Usage:
```bash
lsof -i :5000
lsof -i :5001
lsof -i :5002
lsof -i :5003
lsof -i :5004
lsof -i :5005
```

### Kill Process on Port:
```bash
# Find PID, then:
kill <PID>
# Or force kill:
kill -9 <PID>
```

### Check Service Status:
```bash
# Via API:
curl http://localhost:5005/api/status/project_dashboard
curl http://localhost:5005/api/status/project_hub
curl http://localhost:5005/api/status/midnight
```

### Manual Service Start:
```bash
cd /mnt/c/projects/<service-dir>
source venv/bin/activate
python3 <script>.py
```

---

## 📞 BROWSER CONSOLE ERRORS

When debugging, check browser console (F12) for:
- Network tab: API call status codes
- Console tab: JavaScript errors
- Look for failed requests or extension conflicts

---

## ✅ SUCCESS CRITERIA

Service Manager is fully functional when:
- [ ] All services listed in dashboard
- [ ] Start buttons trigger service launches
- [ ] Stop buttons terminate services correctly
- [ ] Status indicators update in real-time
- [ ] No port conflicts exist
- [ ] All dependencies installed
- [ ] Services accessible at their designated ports

---

## 📝 NOTES

- Midnight Infrastructure (port 5003) is confirmed working ✅
- Service Manager using correct paths after fixes ✅
- Virtual environments exist but lack dependencies ⚠️
- Config.py and api.py had mismatched service definitions (now fixed) ✅

---

**Last Updated:** October 28, 2025, 22:45 UTC  
**Next Review:** After dependency installation complete
