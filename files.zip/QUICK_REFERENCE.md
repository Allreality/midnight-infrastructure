# Multi-Service Manager - Quick Reference Guide
**Last Updated:** October 28, 2025

---

## 🚀 QUICK START

### Start Everything (Recommended Order):

```bash
# 1. Start Service Manager
cd /mnt/c/projects/service_manager
source venv/bin/activate
python3 api.py
# Access at: http://localhost:5005

# 2. Start Midnight Infrastructure (already working)
cd /mnt/c/projects/midnight-infrastructure
python3 app.py
# Access at: http://localhost:5003

# 3. Start Project Dashboard (after fixing deps)
cd /mnt/c/projects/project-dashboard
source venv/bin/activate
python3 server.py
# Access at: http://localhost:5000

# 4. Start Project Hub
cd /mnt/c/projects/project-hub
source venv/bin/activate
python3 app.py
# Access at: http://localhost:5001
```

---

## 🔧 FIX ALL SERVICES AT ONCE

Run the automated fix script:

```bash
cd /mnt/c/projects
# Copy the fix script from Claude's workspace
cp /home/claude/fix_all_services.sh ./
chmod +x fix_all_services.sh
./fix_all_services.sh
```

This will:
- Install all missing dependencies
- Create requirements.txt files
- Backup everything first
- Generate a completion report

---

## 📋 PORT REFERENCE

| Port | Service | Status | URL |
|------|---------|--------|-----|
| 5000 | Project Dashboard | Needs deps | http://localhost:5000 |
| 5001 | Project Hub | Needs deps | http://localhost:5001 |
| 5002 | Trading Control | Needs setup | http://localhost:5002 |
| 5003 | Midnight Infrastructure | ✅ Working | http://localhost:5003 |
| 5004 | Trading Bot Dashboard | Needs setup | http://localhost:5004 |
| 5005 | Service Manager | ✅ Working | http://localhost:5005 |

---

## 🐛 TROUBLESHOOTING

### Service Won't Start

```bash
# Check if port is in use
lsof -i :<port>

# Kill process using port
kill <PID>

# Check for errors
cd /mnt/c/projects/<service-name>
source venv/bin/activate
python3 <script>.py
# Read error message
```

### Missing Module Error

```bash
cd /mnt/c/projects/<service-name>
source venv/bin/activate
pip install <module-name>
```

### Port Already in Use

```bash
# Find what's using the port
lsof -i :<port>

# Kill it
kill -9 <PID>

# Or use different port (update config)
```

---

## 📦 MANUAL DEPENDENCY INSTALLATION

### Project Dashboard (Port 5000):

```bash
cd /mnt/c/projects/project-dashboard
source venv/bin/activate
pip install fastapi uvicorn jinja2 python-multipart requests
pip freeze > requirements.txt
python3 server.py
```

### Project Hub (Port 5001):

```bash
cd /mnt/c/projects/project-hub
source venv/bin/activate  
pip install fastapi uvicorn jinja2 python-multipart requests
pip freeze > requirements.txt
python3 app.py
```

### Midnight Infrastructure (Port 5003):

```bash
# Already working! ✅
cd /mnt/c/projects/midnight-infrastructure
python3 app.py
```

---

## 🔍 HEALTH CHECKS

### Check All Services:

```bash
# Service Manager API
curl http://localhost:5005/api/status/project_dashboard
curl http://localhost:5005/api/status/project_hub
curl http://localhost:5005/api/status/midnight

# Direct service checks
curl http://localhost:5000/  # Project Dashboard
curl http://localhost:5001/  # Project Hub
curl http://localhost:5003/  # Midnight Infrastructure
```

### Check Running Processes:

```bash
# All Python processes
ps aux | grep python | grep -E "(api.py|server.py|app.py)"

# Check specific port
lsof -i :5005
```

---

## 📝 COMMON COMMANDS

### Stop All Services:

```bash
# Find all service processes
ps aux | grep python | grep -E "(5000|5001|5002|5003|5004|5005)"

# Kill them
pkill -f "python3 api.py"
pkill -f "python3 server.py"
pkill -f "python3 app.py"

# Or use the stop script
cd /mnt/c/projects/service_manager
./stop_all.sh
```

### Restart Service Manager:

```bash
# Stop
pkill -f "api.py"

# Start
cd /mnt/c/projects/service_manager
source venv/bin/activate
python3 api.py
```

### View Logs:

```bash
# Service Manager logs (if running in background)
tail -f /mnt/c/projects/service_manager/logs/*.log

# Or check terminal output where service is running
```

---

## 🎯 TESTING CHECKLIST

After fixing dependencies, verify:

- [ ] Service Manager loads at localhost:5005
- [ ] All service cards display correctly
- [ ] Start buttons trigger service launches
- [ ] Stop buttons terminate services
- [ ] Status indicators update (Stopped/Running)
- [ ] Each service accessible at its port
- [ ] No console errors in browser (F12)
- [ ] No port conflicts

---

## 📚 DOCUMENTATION FILES

| File | Location | Purpose |
|------|----------|---------|
| `SERVICE_MANAGER_FIXES_2025-10-28.md` | `/home/claude/` | Complete troubleshooting log |
| `CLAUDE_PROOF_SETUP.md` | `/home/claude/` | Claude-proof installation guide |
| `fix_all_services.sh` | `/home/claude/` | Automated fix script |
| `QUICK_REFERENCE.md` | `/home/claude/` | This file |

### Copy to Your Project:

```bash
# Copy all documentation
cp /home/claude/*.md /mnt/c/projects/docs/
cp /home/claude/fix_all_services.sh /mnt/c/projects/
```

---

## 🎓 BEST PRACTICES

1. **Always start Service Manager first** (port 5005)
2. **Test services individually** before using manager
3. **Check logs** when services fail to start
4. **Keep backups** before making changes
5. **Document changes** in Claude-proof logs
6. **Use virtual environments** for each service
7. **Create requirements.txt** after installing deps

---

## 🆘 EMERGENCY RECOVERY

### If Everything Breaks:

```bash
# 1. Stop all services
pkill -f python3

# 2. Restore from backup
cd /mnt/c/projects/service_manager
cp api.py.backup_* api.py

# 3. Start fresh
./fresh_start.sh

# 4. Or run diagnostic
./diagnose.sh
```

---

## ✅ SUCCESS INDICATORS

Everything is working when:

✅ Service Manager dashboard loads  
✅ All 5 services show in cards  
✅ Start buttons launch services  
✅ Services respond at their URLs  
✅ Status updates show "Running"  
✅ No browser console errors  
✅ No port conflicts  

---

**Status:** Documentation complete  
**Action:** Run automated fix script or install dependencies manually  
**Support:** Review SERVICE_MANAGER_FIXES_2025-10-28.md for details
