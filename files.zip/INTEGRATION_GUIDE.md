# Integration Guide: Adding Service Monitor to Project Dashboard

## Step 1: Copy the service_monitor.py module

Copy `service_monitor.py` to your project directory:

```bash
cp /mnt/user-data/outputs/service_monitor.py /mnt/c/projects/project-dashboard/
```

## Step 2: Add to your server.py (FastAPI version)

Add these imports at the top of server.py:

```python
from service_monitor import ServiceMonitor
from fastapi.responses import HTMLResponse, JSONResponse
```

Add this API endpoint to your FastAPI app:

```python
@app.get("/api/services")
async def get_services():
    """API endpoint to get service status"""
    monitor = ServiceMonitor()
    services = monitor.get_all_services_status()
    return JSONResponse(content=services)
```

## Step 3: Add to your HTML template

Add this HTML code near the top of your dashboard (after the header):

```html
<!-- Service Status Panel -->
<div id="service-status-panel" class="service-status-container">
    <div class="panel-header">
        <h2>🚀 Service Status Monitor</h2>
        <button onclick="refreshServices()" class="refresh-btn">🔄 Refresh</button>
    </div>
    <div id="services-grid" class="services-grid">
        <!-- Services will be loaded here -->
    </div>
</div>
```

## Step 4: Add CSS styling

Add this CSS to your stylesheet or in a <style> tag:

```css
.service-status-container {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    border-radius: 15px;
    padding: 25px;
    margin: 20px 0;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
}

.panel-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
    color: white;
}

.panel-header h2 {
    margin: 0;
    font-size: 1.8em;
}

.refresh-btn {
    background: rgba(255, 255, 255, 0.2);
    border: 2px solid rgba(255, 255, 255, 0.3);
    color: white;
    padding: 10px 20px;
    border-radius: 8px;
    cursor: pointer;
    font-size: 1em;
    transition: all 0.3s ease;
}

.refresh-btn:hover {
    background: rgba(255, 255, 255, 0.3);
    transform: scale(1.05);
}

.services-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 15px;
}

.service-card {
    background: rgba(255, 255, 255, 0.95);
    border-radius: 12px;
    padding: 20px;
    transition: all 0.3s ease;
    border-left: 5px solid #ccc;
}

.service-card.running {
    border-left-color: #10b981;
    box-shadow: 0 4px 6px rgba(16, 185, 129, 0.1);
}

.service-card.stopped {
    border-left-color: #ef4444;
    opacity: 0.7;
}

.service-card:hover {
    transform: translateY(-3px);
    box-shadow: 0 8px 15px rgba(0, 0, 0, 0.2);
}

.service-header {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 10px;
    font-weight: bold;
    font-size: 1.1em;
}

.status-icon {
    font-size: 1.3em;
}

.service-name {
    flex: 1;
    color: #1f2937;
}

.service-port {
    background: #f3f4f6;
    padding: 4px 10px;
    border-radius: 6px;
    font-family: monospace;
    color: #6b7280;
    font-size: 0.9em;
}

.service-description {
    color: #6b7280;
    font-size: 0.9em;
    margin-bottom: 10px;
    min-height: 40px;
}

.service-details {
    margin-top: 10px;
    padding-top: 10px;
    border-top: 1px solid #e5e7eb;
    font-size: 0.85em;
    color: #9ca3af;
}

.service-details a {
    color: #667eea;
    text-decoration: none;
    font-weight: bold;
}

.service-details a:hover {
    text-decoration: underline;
}

/* Loading animation */
.loading {
    text-align: center;
    padding: 20px;
    color: white;
    font-size: 1.2em;
}

.loading::after {
    content: '...';
    animation: dots 1.5s infinite;
}

@keyframes dots {
    0%, 20% { content: '.'; }
    40% { content: '..'; }
    60%, 100% { content: '...'; }
}
```

## Step 5: Add JavaScript to load services

Add this JavaScript code:

```javascript
// Load and display services
async function loadServices() {
    const grid = document.getElementById('services-grid');
    grid.innerHTML = '<div class="loading">Loading services</div>';
    
    try {
        const response = await fetch('/api/services');
        const services = await response.json();
        
        grid.innerHTML = '';
        
        services.forEach(service => {
            const card = document.createElement('div');
            card.className = `service-card ${service.status}`;
            
            const statusIcon = service.status === 'running' ? '🟢' : '🔴';
            
            let detailsHTML = '';
            if (service.status === 'running') {
                detailsHTML = `
                    <div class="service-details">
                        <small>PID: ${service.pid} | 
                        <a href="${service.url}" target="_blank">Open Dashboard</a>
                        </small>
                    </div>
                `;
            }
            
            card.innerHTML = `
                <div class="service-header">
                    <span class="status-icon">${statusIcon}</span>
                    <span class="service-name">${service.name}</span>
                    <span class="service-port">:${service.port}</span>
                </div>
                <div class="service-description">${service.description}</div>
                ${detailsHTML}
            `;
            
            grid.appendChild(card);
        });
    } catch (error) {
        grid.innerHTML = '<div class="loading" style="color: #ef4444;">Error loading services</div>';
        console.error('Error loading services:', error);
    }
}

// Refresh services
function refreshServices() {
    loadServices();
}

// Load services when page loads
document.addEventListener('DOMContentLoaded', loadServices);

// Auto-refresh every 10 seconds
setInterval(loadServices, 10000);
```

## Complete Example Integration

Here's a complete example of how to add it to your server.py:

```python
from fastapi import FastAPI
from fastapi.responses import HTMLResponse, JSONResponse
from service_monitor import ServiceMonitor

app = FastAPI()

@app.get("/api/services")
async def get_services():
    """Get status of all services"""
    monitor = ServiceMonitor()
    services = monitor.get_all_services_status()
    return JSONResponse(content=services)

@app.get("/", response_class=HTMLResponse)
async def dashboard():
    """Main dashboard page"""
    return """
    <!DOCTYPE html>
    <html>
    <head>
        <title>Project Dashboard</title>
        <style>
            /* Add all the CSS from above here */
        </style>
    </head>
    <body>
        <div class="container">
            <h1>Project Dashboard</h1>
            
            <!-- Service Status Panel -->
            <div id="service-status-panel" class="service-status-container">
                <div class="panel-header">
                    <h2>🚀 Service Status Monitor</h2>
                    <button onclick="refreshServices()" class="refresh-btn">🔄 Refresh</button>
                </div>
                <div id="services-grid" class="services-grid">
                    <!-- Services will be loaded here -->
                </div>
            </div>
            
            <!-- Rest of your dashboard content -->
        </div>
        
        <script>
            /* Add all the JavaScript from above here */
        </script>
    </body>
    </html>
    """

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=5000)
```

## Testing

1. Start your dashboard:
   ```bash
   cd /mnt/c/projects/project-dashboard
   source venv/bin/activate
   python3 server.py
   ```

2. Open http://localhost:5000 in your browser

3. You should see a service monitor panel at the top showing all services with:
   - Green dot (🟢) = Running
   - Red dot (🔴) = Stopped
   - Port numbers
   - Clickable links to running services
   - Auto-refresh every 10 seconds

## Customization

You can customize the KNOWN_SERVICES in service_monitor.py to add/remove services:

```python
KNOWN_SERVICES = {
    5000: {'name': 'Your Service', 'description': 'Description here'},
    # Add more services...
}
```
