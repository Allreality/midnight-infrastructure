#!/bin/bash
# Multi-Service Manager - Automated Dependency Installation & Testing
# Date: October 28, 2025
# Purpose: Install missing dependencies and test all services

set -e  # Exit on error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Logging function
log() {
    echo -e "${BLUE}[$(date '+%Y-%m-%d %H:%M:%S')]${NC} $1"
}

success() {
    echo -e "${GREEN}✅ $1${NC}"
}

error() {
    echo -e "${RED}❌ $1${NC}"
}

warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

# Base path
PROJECTS_ROOT="/mnt/c/projects"

# Service definitions
declare -A SERVICES
SERVICES=(
    ["project-dashboard"]="5000:server.py"
    ["project-hub"]="5001:app.py"
    ["midnight-infrastructure"]="5003:app.py"
)

log "========================================="
log "Multi-Service Manager Fix Script"
log "========================================="
echo ""

# Function to check if venv exists
check_venv() {
    local service_path="$1"
    if [ -d "$service_path/venv" ]; then
        success "Virtual environment found"
        return 0
    else
        error "Virtual environment not found"
        return 1
    fi
}

# Function to install common dependencies
install_dependencies() {
    local service_path="$1"
    local service_name="$2"
    
    log "Installing dependencies for $service_name..."
    
    cd "$service_path"
    
    # Activate venv
    source venv/bin/activate
    
    # Upgrade pip
    pip install --upgrade pip --quiet
    
    # Common dependencies for web services
    local deps=(
        "fastapi"
        "uvicorn"
        "jinja2"
        "python-multipart"
        "requests"
        "aiofiles"
        "python-jose"
        "passlib"
        "bcrypt"
    )
    
    for dep in "${deps[@]}"; do
        log "  Installing $dep..."
        pip install "$dep" --quiet 2>/dev/null || warning "  Could not install $dep (may not be needed)"
    done
    
    # Create requirements.txt
    log "  Creating requirements.txt..."
    pip freeze > requirements.txt
    
    success "Dependencies installed for $service_name"
    deactivate
}

# Function to test service startup
test_service() {
    local service_path="$1"
    local service_script="$2"
    local service_name="$3"
    
    log "Testing $service_name startup..."
    
    cd "$service_path"
    source venv/bin/activate
    
    # Try to start the service (with timeout)
    timeout 5 python3 "$service_script" 2>&1 | head -20 || {
        error "Service failed to start or timed out (this may be normal if it's waiting for connections)"
    }
    
    deactivate
}

# Main execution
main() {
    log "Starting automated fixes..."
    echo ""
    
    # Create Claude-proof backup directory
    log "Setting up Claude-proof backups..."
    BACKUP_DIR="$PROJECTS_ROOT/.claude-proof-backups/$(date +%Y%m%d_%H%M%S)"
    mkdir -p "$BACKUP_DIR"
    success "Backup directory created: $BACKUP_DIR"
    echo ""
    
    # Process each service
    for service_name in "${!SERVICES[@]}"; do
        IFS=':' read -r port script <<< "${SERVICES[$service_name]}"
        service_path="$PROJECTS_ROOT/$service_name"
        
        log "========================================="
        log "Processing: $service_name"
        log "  Port: $port"
        log "  Script: $script"
        log "  Path: $service_path"
        log "========================================="
        
        # Check if service directory exists
        if [ ! -d "$service_path" ]; then
            error "Service directory not found: $service_path"
            echo ""
            continue
        fi
        
        # Backup current state
        log "Creating backup..."
        cp -r "$service_path" "$BACKUP_DIR/$service_name" 2>/dev/null || warning "Could not create backup"
        
        # Check venv
        if ! check_venv "$service_path"; then
            warning "Creating virtual environment..."
            cd "$service_path"
            python3 -m venv venv
        fi
        
        # Install dependencies
        install_dependencies "$service_path" "$service_name"
        
        # Test service
        # test_service "$service_path" "$script" "$service_name"
        
        success "Completed processing $service_name"
        echo ""
    done
    
    # Create summary report
    log "========================================="
    log "Creating summary report..."
    log "========================================="
    
    cat > "$PROJECTS_ROOT/SERVICE_FIX_REPORT_$(date +%Y%m%d_%H%M%S).txt" << EOF
Multi-Service Manager - Fix Report
Generated: $(date)
================================================

Services Processed:
$(for service in "${!SERVICES[@]}"; do echo "  ✓ $service"; done)

Backups Created:
  Location: $BACKUP_DIR

Dependencies Installed:
  - fastapi
  - uvicorn
  - jinja2
  - python-multipart
  - requests
  - aiofiles

Requirements Files Created:
$(for service in "${!SERVICES[@]}"; do 
    if [ -f "$PROJECTS_ROOT/$service/requirements.txt" ]; then 
        echo "  ✓ $service/requirements.txt"
    fi
done)

Next Steps:
1. Test each service manually:
   cd /mnt/c/projects/<service-name>
   source venv/bin/activate
   python3 <script>.py

2. Start Service Manager:
   cd /mnt/c/projects/service_manager
   source venv/bin/activate
   python3 api.py

3. Test from web interface:
   http://localhost:5005

================================================
EOF
    
    success "Report created!"
    echo ""
    
    log "========================================="
    log "SUMMARY"
    log "========================================="
    success "All services processed"
    success "Dependencies installed"
    success "Requirements.txt files created"
    success "Backups saved to: $BACKUP_DIR"
    echo ""
    warning "IMPORTANT: Test each service manually before using Service Manager"
    echo ""
    log "Run this to test Project Dashboard:"
    echo "  cd /mnt/c/projects/project-dashboard"
    echo "  source venv/bin/activate"
    echo "  python3 server.py"
    echo ""
}

# Run main function
main

success "Script completed!"
log "Check the report file in /mnt/c/projects/ for details"
